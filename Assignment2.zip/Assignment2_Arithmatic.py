def add(no1,no2):
    no1=int(no1)
    no2=int(no2)
    return no1+no2

def substract(no1,no2):
    no1=int(no1)
    no2=int(no2)
    return no1-no2

def Division(no1,no2):
    no1=int(no1)
    no2=int(no2)
    return no1/no2

def Multiplication(no1,no2):
    no1=int(no1)
    no2=int(no2)
    return no1*no2
