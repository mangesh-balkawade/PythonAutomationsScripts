def fun():
    print("Hello From Fun")

def main():
    fun()

if __name__=="__main__":
    main()