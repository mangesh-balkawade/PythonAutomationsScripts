def display(no):
    no=int(no)
    for i in range(1,no+1):
        print("Marvellous")

def main():
    print("Enter no")
    no=input()
    display(no)

if __name__=="__main__":
    main()