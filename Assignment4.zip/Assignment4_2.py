def main():
    multLambda=lambda no1,no2:no1*no2
    print("Enter First No ")
    ino1=int(input())
    print("Enter Second No ")
    ino2 = int(input())
    print("Multiplication of numbers using lambada is :",multLambda(ino1,ino2))


if __name__=="__main__":
    main()

