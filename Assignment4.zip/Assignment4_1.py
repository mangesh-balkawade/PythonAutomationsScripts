def main():
    powerLambda=lambda power:2**power
    print("Enter No ")
    ino=int(input())
    print("Power of no raised 2 is :",powerLambda(ino))


if __name__=="__main__":
    main()

